//
//  Rock__Papper__Sisers_challangeApp.swift
//  Rock, Papper, Sisers challange
//
//  Created by Link, Ty - Student on 10/2/24.
//

import SwiftUI

@main
struct Rock__Papper__Sisers_challangeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
